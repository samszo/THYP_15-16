var map;
var markers = [];
var position;
var people= [];
var scores= [];


/* init Maps and load all documents
**/
function initMap() {
  map = new google.maps.Map(document.getElementById('map'), {
	center: {lat: 40.416775, lng: -3.703790},
	zoom: 5
  });
  
  // center of CA to compute the distance
  myCoordinates = new google.maps.LatLng(38.134557,-120.585938);

  map.addListener('click',addMarker);
  
  selectAllPersonnes();
  selectAllScores();
}

/* add a Marker on the Map 
**/
function addMarker(event) 
{
	var marker = new google.maps.Marker({
	position: event.latLng,
	map: map
	});
  
	if(markers.length > 0) {
		markers[0].setMap(null);
	}
	
	markers[0] = marker;
	position = marker.getPosition();
	document.getElementById("latlng_document").value = "POINT("+position.lat()+" "+position.lng()+")";
}

//********* insert Document and Person functions********
function insertPersonne()
{
	var nom = document.getElementById("nom_personne").value;
	var data = {"table":"personne"};
	if(nom.length >0 && nom.length <20 )
	{
		data.nom = nom;
		$.ajax({
		  url: '../php/c.php',
		  data: data,
		  success: function(html){
				notify("log_personne","Membre ajouté");	
       		},
		  error: function(xhr, ajaxOptions, thrownError){
				notify("log_personne","Erreur serveur impossible d'ajouté cet utilisateur");	
			}
		});
	}
	else
	{
		notify("log_personne","remplissez bien le champ s.v.p");
	}

}

/* for errors msgs 
**/
function notify(attr, msg)
{
	showElementById(attr);
	document.getElementById(attr).innerHTML = msg;
	// hide log after 3 sec
	setTimeout(function(){
		hideElementById(attr);
	}, 3000);
}

function insertDocument()
{
	var data = {"table":"document"};
	
	var nom = document.getElementById("nom_document").value;
	var latlng =  "ST_GeomFromText('POINT("+position.lat()+"  "+position.lng()+")')";
	var url = document.getElementById("url_document").value;;
	
	if(nom.length >0 && latlng.length >0 && url.length >0)
	{
		data.nom = nom;
		data.latlng = latlng;
		data.url = url;

		$.ajax({
		  url: '../php/c.php',
		  data: data,
		  success: function(html){
				notify("log_document","Document ajouté");	
       		},
		  error: function(xhr, ajaxOptions, thrownError){
				notify("log_document","Erreur serveur impossible d'ajouté ce document");	
			}
		});
	}
	else
	{
		notify("log_document","Saisissez tous les champs s.v.p");
	}

}


/* send an ajax request with a new score 
* handle if it's an update/insert request
**/
function creaScore(data){
	data.table = "score";
	var id_score;
	// lookup wheter it's an update/insert Request
	if(scores !== undefined){
		scores.forEach(function(score){
			//update request
			if(score['id_perso'] === data['id_perso'] && score['id_doc'] === data['id_doc'])
			{
				id_score = score['id_scores'];
			}
		
		});
	
	}
	
	//update
	if(id_score !== undefined)
	{
		data['id_score'] = id_score;
		$.get('../php/u.php', data, function(html){
			loadScore(data['id_doc'], false);
		});	
		
	}
	else
	{
		// insert
		$.get('../php/c.php', data
		, function(html){
			// get id of the inserted score
			loadScore(data['id_doc'], true);
		});	
		
	}
}

/* select all personnes function
**/
function selectAllPersonnes()
{	
	var data ={"table":"personnes"};
		
	$.ajax({
	  url: '../php/r.php',
	  data: data,
	  success: function(html){
				members = JSON.parse(html);
				populateGridPersonnes(members);
		}
	});

}


function populateGridPersonnes(members)
{
	
	members.forEach(function(member){
		people.push({recid: member["id_perso"], text: member["nom"], check: false });
	
	});
	
	$(function () {
		$('#grid').w2grid({ 
			name: 'grid', 
			show: { 
				toolbar: true,
				footer: true,
				toolbarSave: true
			},
			columns: [                
				{ field: 'recid', caption: 'ID', size: '80px', sortable: true, resizable: true },
				{ field: 'text', caption: 'Login Github', size: '740px', sortable: true, resizable: true, 
					editable: { type: 'text' }
				},
				{ field: 'check', caption: 'cocher', size: '100px', sortable: true, resizable: true, 
					editable: { type: 'checkbox' } 
				}],
			toolbar: {
				items: [
					{ id: 'add', type: 'button', caption: 'Add Personne', icon: 'w2ui-icon-plus' },
					{ id: 'supprimer', type: 'button', caption: 'Delete Personne', icon: 'w2ui-icon-cross' }
				],
				onClick: function (event) {
					if (event.target == 'add') {
						w2ui.grid.add({ recid: w2ui.grid.records.length + 1 });
					}
				}
			},
			records: people
		});    
	});
}

function showChanged() {
    console.log(w2ui['grid'].getChanges()); 
    w2alert('Changed records are displayed in the console');
}


/* select all scores function
**/
function selectAllScores()
{	
	var data ={"table":"allscores"};
		
	$.ajax({
	  url: '../php/r.php',
	  data: data,
	  success: function(html){
				myScores = JSON.parse(html);
				populateGridScores(myScores);
		}
	});

}


function populateGridScores(myScores)
{
	
	myScores.forEach(function(s){
		var name = getMemberName(s["id_perso"]);
		scores.push({recid: s["id_scores"], text: name, document: s["id_doc"], distance: s["distance"], time: s["maj"], check: false });
	
	});
	
	$(function () {
		$('#gridscores').w2grid({ 
			name: 'gridscores', 
			show: { 
				toolbar: true,
				footer: true
			},
			columns: [                
				{ field: 'recid', caption: 'ID Score', size: '80px', sortable: true, resizable: true },
				{ field: 'text', caption: 'Login Github', size: '140px', sortable: true, resizable: true, editable: false},
				{ field: 'document', caption: 'ID Document', size: '140px', sortable: true, resizable: true, editable: false},
				{ field: 'distance', caption: 'Distance', size: '140px', sortable: true, resizable: true, editable: false},
				{ field: 'time', caption: 'Date', size: '140px', sortable: true, resizable: true, editable: false},
				{ field: 'check', caption: 'Cocher', size: '140px', sortable: false, resizable: true, editable: { type: 'checkbox' }} 
				],
			toolbar: {
				items: [
					{ id: 'supprimer', type: 'button', caption: 'Delete Score', icon: 'w2ui-icon-cross' }
				],
				onClick: function (event) {
					if (event.target == 'add') {
						w2ui.grid.add({ recid: w2ui.grid.records.length + 1 });
					}
				}
			},
			records: scores
		});    
	});
}


/*get member Id
*/
function getMemberName(id)
{
	var name;
	people.forEach(function(m){
	
		if(m['recid'] === id){
			name =  m['text'];
		}
	
	});
	
	return name;

}
/* show an element given its Id
**/
function showElementById(attr) 
{
	document.getElementById(attr).style.display = "block";
}

/* hide an element given its Id
**/
function hideElementById(attr)
 {
	document.getElementById(attr).style.display = "none";
}